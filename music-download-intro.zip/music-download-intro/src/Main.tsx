import React from "react";
import { AbsoluteFill, Sequence } from "remotion";
import { FontGate } from "./components/FontGate";
import { BgMesh, Grade, Grain, Vignette } from "./components/Layers";
import { PreviewAudio } from "./components/PreviewAudio";
import { SceneFrame } from "./scene";
import { CapCut } from "./scenes/CapCut";
import { Flow } from "./scenes/Flow";
import { Hook } from "./scenes/Hook";
import { Music } from "./scenes/Music";
import { Question } from "./scenes/Question";
import { SCENES, SceneId } from "./timeline";
import { theme } from "./theme";

const COMPONENTS: Record<SceneId, React.FC> = {
  hook: Hook,
  music: Music,
  flow: Flow,
  question: Question,
  capcut: CapCut,
};

// Layer stack (bottom → top): BgMesh → scenes (assets + graphics + type) → Grade → Grain → Vignette
export const Main: React.FC = () => (
  <FontGate>
    <AbsoluteFill style={{ backgroundColor: theme.colors.bg, fontFamily: theme.fonts.display }}>
      <BgMesh />
      {SCENES.map((s) => {
        const Scene = COMPONENTS[s.id];
        return (
          <Sequence key={s.id} name={s.id} from={s.from} durationInFrames={s.duration}>
            <SceneFrame from={s.from} duration={s.duration}>
              <Scene />
            </SceneFrame>
          </Sequence>
        );
      })}
      <Grade />
      <Grain />
      <Vignette />
      <PreviewAudio />
    </AbsoluteFill>
  </FontGate>
);
