// theme.ts — single source of truth: colors, fonts, easings, spring presets, shapes.
// Color scheme: "Midnight Neon" (user pick #1). Never inline a hex/easing/spring in components.
import { Easing } from "remotion";

const hero = "#7C5CFF";
const accent = "#22E6F2";

export const alpha = (hex: string, a: number): string => {
  const n = parseInt(hex.slice(1), 16);
  return `rgba(${(n >> 16) & 255}, ${(n >> 8) & 255}, ${n & 255}, ${a})`;
};

export const theme = {
  colors: {
    bg: "#0B0B14",
    bgAlt: "#15152B",
    hero, // THE hero color — keep to one focal element per frame
    accent,
    text: "#FFFFFF",
    textDim: "rgba(255,255,255,0.64)",
    textFaint: "rgba(255,255,255,0.38)",
    surface: "rgba(255,255,255,0.06)",
    surfaceStrong: "rgba(255,255,255,0.13)",
    border: "rgba(255,255,255,0.14)",
    heroGlow: alpha(hero, 0.5),
    heroSoft: alpha(hero, 0.34),
    accentGlow: alpha(accent, 0.4),
    accentSoft: alpha(accent, 0.18),
    tile: "#FFFFFF",
    ink: "#0B0B14",
    shadow: "rgba(0,0,0,0.6)",
  },
  gradients: {
    keyword: `linear-gradient(100deg, ${hero} 0%, ${accent} 100%)`,
    card: "linear-gradient(150deg, rgba(255,255,255,0.13), rgba(255,255,255,0.04))",
  },
  fonts: {
    // One family for everything (Bengali + Latin), bundled via @fontsource (works offline).
    display: '"Hind Siliguri", system-ui, sans-serif',
  },
  weights: { hero: 700, strong: 600, body: 500 },
  radius: { card: 48, inner: 30, tile: 0.22, pill: 999 },
  shadow: {
    card: "0 50px 100px -30px rgba(0,0,0,0.75), inset 0 1px 0 rgba(255,255,255,0.16)",
    tile: "drop-shadow(0 30px 40px rgba(0,0,0,0.5))",
  },
  // THE easing curves. Linear is not used anywhere.
  ease: {
    out: Easing.bezier(0.16, 1, 0.3, 1),
    inOut: Easing.bezier(0.83, 0, 0.17, 1),
    in: Easing.bezier(0.7, 0, 0.84, 0),
  },
  spring: {
    snappy: { damping: 14, stiffness: 160, mass: 0.6 },
    smooth: { damping: 20, stiffness: 90, mass: 1 },
    bouncy: { damping: 11, stiffness: 170, mass: 0.7 },
  },
  motion: {
    /** Visuals enter this many frames BEFORE the matching spoken words (4–6 asked for). */
    lead: 5,
    /** Overlap (frames) between an outgoing and the next scene = transition length. */
    xfade: 8,
    /** Final fade-out length (frames) at the very end of the video. */
    outro: 10,
  },
} as const;

export const clampBoth = {
  extrapolateLeft: "clamp",
  extrapolateRight: "clamp",
} as const;
