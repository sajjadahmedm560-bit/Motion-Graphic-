import React, { createContext, useContext } from "react";
import { interpolate, useCurrentFrame } from "remotion";
import { cueIn, cueItemIn, TOTAL_FRAMES } from "./srt";
import { clampBoth, theme } from "./theme";

type SceneInfo = { from: number; duration: number; last: boolean };

const SceneCtx = createContext<SceneInfo>({ from: 0, duration: 1, last: false });

/** Maps SRT cues to the scene's LOCAL frame numbers. Visuals enter `lead` frames before the words. */
export const useScene = () => {
  const { from, duration, last } = useContext(SceneCtx);
  const lead = theme.motion.lead;
  return {
    from,
    duration,
    last,
    /** local frame at which the visual for cue `n` should START entering */
    at: (n: number): number => cueIn(n) - from - lead,
    /** same, for item k of `total` named inside one cue (equal spacing) */
    atItem: (n: number, k: number, total: number): number => cueItemIn(n, k, total) - from - lead,
  };
};

/** Wraps one scene: provides timing context and the exit transition (whip-blur out). */
export const SceneFrame: React.FC<{
  from: number;
  duration: number;
  children: React.ReactNode;
}> = ({ from, duration, children }) => {
  const frame = useCurrentFrame();
  const last = from + duration >= TOTAL_FRAMES;
  const len = last ? theme.motion.outro : theme.motion.xfade;
  const p = interpolate(frame, [duration - len, duration], [0, 1], {
    easing: last ? theme.ease.inOut : theme.ease.in,
    ...clampBoth,
  });
  return (
    <SceneCtx.Provider value={{ from, duration, last }}>
      <div
        style={{
          position: "absolute",
          inset: 0,
          opacity: 1 - p,
          transform: last ? undefined : `translateX(${-150 * p}px)`,
          filter: !last && p > 0 ? `blur(${p * 12}px)` : undefined,
        }}
      >
        {children}
      </div>
    </SceneCtx.Provider>
  );
};
