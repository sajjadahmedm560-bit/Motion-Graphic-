// The voiceover SRT is the ONLY timing source. Every frame number in the video is derived from it.
import { FPS } from "./config";

export const SRT_RAW = `1
00:00:00,170 --> 00:00:00,930
আপনার YouTube এর

2
00:00:00,930 --> 00:00:01,870
ভিতরে গিয়ে বা

3
00:00:01,870 --> 00:00:02,670
TikTok এর ভিতরে

4
00:00:02,670 --> 00:00:03,370
গিয়ে যখন গান

5
00:00:03,370 --> 00:00:04,170
দেখেন তখন

6
00:00:04,170 --> 00:00:04,830
কিন্তু একটা না

7
00:00:04,830 --> 00:00:05,590
একটা গান ভালো

8
00:00:05,590 --> 00:00:06,570
লেগে যায় এবং

9
00:00:06,570 --> 00:00:07,450
সবচেয়ে বেশি ভালো

10
00:00:07,450 --> 00:00:08,510
লাগে সেই গানের

11
00:00:08,510 --> 00:00:09,310
ভিতরে যে music

12
00:00:09,310 --> 00:00:10,290
টি রয়েছে সেই

13
00:00:10,290 --> 00:00:10,710
music টি

14
00:00:10,710 --> 00:00:12,010
download করে background

15
00:00:12,010 --> 00:00:12,870
এ রেখে আপনি

16
00:00:12,870 --> 00:00:13,590
নিজের মতো করে

17
00:00:13,590 --> 00:00:14,770
গান গাইতে চাচ্ছেন।

18
00:00:14,770 --> 00:00:15,810
এখন কথা হচ্ছে

19
00:00:15,810 --> 00:00:16,490
এই গানটি আপনি

20
00:00:16,490 --> 00:00:17,850
কিভাবে download দিবেন?

21
00:00:17,850 --> 00:00:18,690
এই বিষয়টা দেখানোর

22
00:00:18,690 --> 00:00:19,870
জন্য অবশ্যই CapCut

23
00:00:19,870 --> 00:00:20,960
টি open করবেন।
`;

export type Cue = { n: number; start: number; end: number; text: string };

const toSec = (h: string, m: string, s: string, ms: string): number =>
  Number(h) * 3600 + Number(m) * 60 + Number(s) + Number(ms.padEnd(3, "0")) / 1000;

export const parseSrt = (raw: string): Cue[] =>
  raw
    .trim()
    .split(/\r?\n\s*\r?\n/)
    .map((block) => {
      const lines = block.split(/\r?\n/);
      const m = lines[1].match(/(\d+):(\d+):(\d+)[,.](\d+)\s*-->\s*(\d+):(\d+):(\d+)[,.](\d+)/);
      if (!m) throw new Error(`Bad SRT timing line: ${lines[1]}`);
      return {
        n: Number(lines[0]),
        start: toSec(m[1], m[2], m[3], m[4]),
        end: toSec(m[5], m[6], m[7], m[8]),
        text: lines.slice(2).join(" "),
      };
    });

export const CUES = parseSrt(SRT_RAW);

const cue = (n: number): Cue => {
  const c = CUES.find((x) => x.n === n);
  if (!c) throw new Error(`No SRT cue #${n}`);
  return c;
};

/** Absolute frame where cue `n` starts being spoken. */
export const cueIn = (n: number): number => Math.round(cue(n).start * FPS);
/** Absolute frame where cue `n` ends. */
export const cueOut = (n: number): number => Math.round(cue(n).end * FPS);
/**
 * When a cue names several items at once, show them at equal spacing across the cue's time.
 * Item `k` (0-based) of `total`.
 */
export const cueItemIn = (n: number, k: number, total: number): number => {
  const c = cue(n);
  return Math.round((c.start + ((c.end - c.start) * k) / total) * FPS);
};

/** Video length = end of the last cue (SRT wins over everything else). */
export const TOTAL_FRAMES = Math.ceil(CUES[CUES.length - 1].end * FPS);
