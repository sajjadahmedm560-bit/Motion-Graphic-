// Project-wide switches. Change here, not inside components.
export const FPS = 30;
export const WIDTH = 1920;
export const HEIGHT = 1080;

export const FLAGS = {
  /** Play public/voiceover.mp3 in Remotion Studio preview (silently skipped if the file is missing). */
  previewVoiceover: true,
  /** Keep false: the voiceover is for preview/sync-checking only and is NOT mixed into renders. */
  voiceoverInRender: false,
  /** Master switch for the synthesized UI sound effects in public/sfx/. */
  sfx: true,
} as const;

export const VOICEOVER_FILE = "voiceover.mp3";
