import React from "react";
import { interpolate, spring, useCurrentFrame, useVideoConfig } from "remotion";
import { clampBoth, theme } from "../theme";

type SpringCfg = { damping: number; stiffness: number; mass: number };

/** spring that is 0 before `delay` and never receives a negative frame */
export const useSpringAt = (delay: number, cfg: SpringCfg = theme.spring.snappy): number => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  return spring({ frame: Math.max(0, frame - delay), fps, config: cfg });
};

/** Premium entrance: opacity + translate + scale together (never a lone fade). */
export const Entrance: React.FC<{
  delay?: number;
  x?: number;
  y?: number;
  scaleFrom?: number;
  cfg?: SpringCfg;
  style?: React.CSSProperties;
  children: React.ReactNode;
}> = ({ delay = 0, x = 0, y = 40, scaleFrom = 0.94, cfg = theme.spring.smooth, style, children }) => {
  const p = useSpringAt(delay, cfg);
  return (
    <div
      style={{
        opacity: Math.min(1, p * 1.5),
        transform: `translate(${(1 - p) * x}px, ${(1 - p) * y}px) scale(${interpolate(p, [0, 1], [scaleFrom, 1])})`,
        ...style,
      }}
    >
      {children}
    </div>
  );
};

/** Faster-than-entrance exit for a block: returns style to spread on a wrapper. */
export const useExit = (startFrame: number, len = 9, dy = -34): React.CSSProperties => {
  const frame = useCurrentFrame();
  const p = interpolate(frame, [startFrame, startFrame + len], [0, 1], {
    easing: theme.ease.in,
    ...clampBoth,
  });
  return {
    opacity: 1 - p,
    transform: `translateY(${dy * p}px) scale(${1 - 0.03 * p})`,
    pointerEvents: "none",
  };
};

/** Idle breathing: anything on screen for more than ~2s gets micro-motion. */
export const Float: React.FC<{
  amp?: number;
  period?: number;
  phase?: number;
  breathe?: number;
  style?: React.CSSProperties;
  children: React.ReactNode;
}> = ({ amp = 6, period = 90, phase = 0, breathe = 0.012, style, children }) => {
  const frame = useCurrentFrame();
  const a = ((frame + phase) / period) * Math.PI * 2;
  return (
    <div style={{ transform: `translateY(${Math.sin(a) * amp}px) scale(${1 + Math.sin(a + 1) * breathe})`, ...style }}>
      {children}
    </div>
  );
};

/** Visible only from frame `from` on (keeps hidden things out of the layout flow of the frame). */
export const visibleFrom = (frame: number, from: number): boolean => frame >= from;

/** glass surface shared by every card in the video */
export const glass = (radius: number = theme.radius.card): React.CSSProperties => ({
  background: theme.gradients.card,
  border: `1px solid ${theme.colors.border}`,
  borderRadius: radius,
  boxShadow: theme.shadow.card,
});
