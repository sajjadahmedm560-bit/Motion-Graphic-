import React from "react";
import { interpolate, useCurrentFrame } from "remotion";
import { clampBoth, theme } from "../theme";

/** Music equalizer bars. Deterministic (no Math.random), staggered intro, idle motion forever. */
export const Equalizer: React.FC<{
  count: number;
  barWidth: number;
  gap: number;
  maxHeight: number;
  delay: number;
  color?: string;
  /** 0..1 – how loud the bars are (use to "push" the music forward) */
  energy?: number;
  align?: "center" | "end";
}> = ({ count, barWidth, gap, maxHeight, delay, color = theme.colors.accent, energy = 1, align = "center" }) => {
  const frame = useCurrentFrame();
  return (
    <div
      style={{
        display: "flex",
        alignItems: align === "center" ? "center" : "flex-end",
        justifyContent: "center",
        gap,
        height: maxHeight,
      }}
    >
      {Array.from({ length: count }).map((_, i) => {
        const base = 0.3 + 0.7 * Math.abs(Math.sin(i * 1.7 + 0.9) * Math.cos(i * 0.43));
        const intro = interpolate(frame, [delay + i * 1.2, delay + i * 1.2 + 16], [0, 1], {
          easing: theme.ease.out,
          ...clampBoth,
        });
        const wob = 0.55 + 0.45 * Math.sin(frame / 5 + i * 0.8);
        const h = Math.max(barWidth, maxHeight * Math.min(1, base * wob * energy + 0.04) * intro);
        return (
          <div
            key={i}
            style={{
              width: barWidth,
              height: h,
              borderRadius: barWidth,
              background: color,
              opacity: 0.45 + 0.5 * base,
            }}
          />
        );
      })}
    </div>
  );
};
