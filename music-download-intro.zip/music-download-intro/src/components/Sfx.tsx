// Tiny UI sound effects (public/sfx/*.wav, synthesized by scripts/make-sfx.mjs).
// Limited kit of 6; the same kind of event always uses the same sound.
import React from "react";
import { Audio, Sequence, staticFile } from "remotion";
import { FLAGS } from "../config";

export type SfxName = "pop" | "click" | "whoosh" | "swipe" | "chime" | "thud";

// Files are baked at peak ~0.26–0.32. These factors even out loudness between them and keep
// everything well below the voiceover (<= 1.0 ⇒ peak never above ~0.32).
const LEVEL: Record<SfxName, number> = {
  pop: 1,
  click: 1,
  whoosh: 0.9,
  swipe: 0.95,
  chime: 1,
  thud: 0.75,
};

const LENGTH_FRAMES: Record<SfxName, number> = {
  pop: 10,
  click: 6,
  whoosh: 26,
  swipe: 14,
  chime: 18,
  thud: 12,
};

/** `at` = local frame (inside the current scene). `rate` ≈ 0.94–1.1 gives small pitch variation. */
export const Sfx: React.FC<{
  name: SfxName;
  at: number;
  volume?: number;
  rate?: number;
}> = ({ name, at, volume = 1, rate = 1 }) => {
  if (!FLAGS.sfx) return null;
  return (
    <Sequence from={Math.max(0, Math.round(at))} durationInFrames={LENGTH_FRAMES[name] + 4} layout="none">
      <Audio src={staticFile(`sfx/${name}.wav`)} volume={LEVEL[name] * volume} playbackRate={rate} />
    </Sequence>
  );
};
