// Hand-built SVG glyphs in theme colors (no emoji, no external icon fonts).
import React from "react";
import { theme } from "../theme";

type IconProps = { size: number; color?: string; strokeWidth?: number; fill?: string; style?: React.CSSProperties };

const Svg: React.FC<IconProps & { viewBox: string; children: React.ReactNode }> = ({
  size,
  viewBox,
  style,
  children,
}) => (
  <svg width={size} height={size} viewBox={viewBox} fill="none" style={{ display: "block", overflow: "visible", ...style }}>
    {children}
  </svg>
);

const base = (p: IconProps) => ({
  stroke: p.color ?? theme.colors.text,
  strokeWidth: p.strokeWidth ?? 4,
  strokeLinecap: "round" as const,
  strokeLinejoin: "round" as const,
});

export const MusicNote: React.FC<IconProps> = (p) => (
  <Svg {...p} viewBox="0 0 64 64">
    <path d="M26 44 V13 L52 7 V37" {...base(p)} />
    <ellipse cx="19" cy="46" rx="9" ry="7" fill={p.fill ?? p.color ?? theme.colors.text} stroke="none" />
    <ellipse cx="45" cy="39" rx="9" ry="7" fill={p.fill ?? p.color ?? theme.colors.text} stroke="none" />
  </Svg>
);

export const Heart: React.FC<IconProps> = (p) => (
  <Svg {...p} viewBox="0 0 64 60">
    <path
      d="M32 56 C10 40 4 27 4 18 C4 9 11 4 19 4 C25 4 30 7 32 12 C34 7 39 4 45 4 C53 4 60 9 60 18 C60 27 54 40 32 56 Z"
      fill={p.fill ?? "none"}
      {...base(p)}
    />
  </Svg>
);

/** arrow pointing down into a tray; `t` (0..1) animates the arrow dropping into the tray */
export const DownloadIcon: React.FC<IconProps & { t?: number }> = ({ t = 0, ...p }) => (
  <Svg {...p} viewBox="0 0 64 64">
    <g transform={`translate(0 ${t * 6})`}>
      <path d="M32 8 V38" {...base(p)} />
      <path d="M18 26 L32 40 L46 26" {...base(p)} />
    </g>
    <path d="M10 44 V52 a4 4 0 0 0 4 4 H50 a4 4 0 0 0 4 -4 V44" {...base(p)} />
  </Svg>
);

export const LayersIcon: React.FC<IconProps> = (p) => (
  <Svg {...p} viewBox="0 0 64 64">
    <path d="M32 8 L58 22 L32 36 L6 22 Z" {...base(p)} />
    <path d="M6 33 L32 47 L58 33" {...base(p)} />
    <path d="M6 44 L32 58 L58 44" {...base(p)} />
  </Svg>
);

export const MicIcon: React.FC<IconProps> = (p) => (
  <Svg {...p} viewBox="0 0 64 64">
    <rect x="22" y="5" width="20" height="33" rx="10" {...base(p)} />
    <path d="M12 30 a20 20 0 0 0 40 0" {...base(p)} />
    <path d="M32 50 V58" {...base(p)} />
    <path d="M22 58 H42" {...base(p)} />
  </Svg>
);

export const PlayIcon: React.FC<IconProps> = (p) => (
  <Svg {...p} viewBox="0 0 64 64">
    <path d="M20 12 L52 32 L20 52 Z" fill={p.fill ?? p.color ?? theme.colors.text} stroke={p.color ?? theme.colors.text} strokeWidth={4} strokeLinejoin="round" />
  </Svg>
);

export const SkipIcon: React.FC<IconProps & { dir: "prev" | "next" }> = ({ dir, ...p }) => (
  <Svg {...p} viewBox="0 0 64 64" style={{ transform: dir === "prev" ? "scaleX(-1)" : undefined, ...p.style }}>
    <path d="M14 14 L42 32 L14 50 Z" fill={p.color ?? theme.colors.text} stroke={p.color ?? theme.colors.text} strokeWidth={4} strokeLinejoin="round" />
    <path d="M52 14 V50" {...base(p)} />
  </Svg>
);

export const ArrowDown: React.FC<IconProps> = (p) => (
  <Svg {...p} viewBox="0 0 64 64">
    <path d="M32 8 V52" {...base(p)} />
    <path d="M14 34 L32 54 L50 34" {...base(p)} />
  </Svg>
);

export const ArrowRight: React.FC<IconProps> = (p) => (
  <Svg {...p} viewBox="0 0 64 64">
    <path d="M8 32 H54" {...base(p)} />
    <path d="M34 12 L54 32 L34 52" {...base(p)} />
  </Svg>
);

export const Cursor: React.FC<{ size: number }> = ({ size }) => (
  <svg width={size} height={size} viewBox="0 0 48 56" style={{ display: "block", overflow: "visible" }}>
    <path
      d="M6 4 L6 42 L16 33 L23 49 L31 45.5 L24 30 L38 30 Z"
      fill={theme.colors.text}
      stroke={theme.colors.ink}
      strokeWidth={3}
      strokeLinejoin="round"
    />
  </svg>
);
