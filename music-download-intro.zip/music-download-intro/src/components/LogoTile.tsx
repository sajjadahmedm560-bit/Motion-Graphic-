// Logos are the user's own files (public/logos/*.png), cropped tight but never redrawn or distorted.
import React from "react";
import { Img, interpolate, spring, staticFile, useCurrentFrame, useVideoConfig } from "remotion";
import { useScene } from "../scene";
import { clampBoth, theme } from "../theme";

export type LogoKey = "youtube" | "tiktok" | "capcut";

// youtube.png is the bare red button (on white) → it sits centered on a white app tile.
// tiktok.png / capcut.png already contain their own rounded tile with transparent corners.
const ASPECT: Record<LogoKey, number> = { youtube: 854 / 600, tiktok: 1024 / 1017, capcut: 1024 / 1018 };

export const LogoTile: React.FC<{
  logo: LogoKey;
  size: number;
  delay: number;
  tilt?: number;
  ringColor?: string;
}> = ({ logo, size, delay, tilt = 0, ringColor = "rgba(255,255,255,0.55)" }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const { duration } = useScene();

  const p = spring({ frame: Math.max(0, frame - delay), fps, config: theme.spring.bouncy });
  const scale = interpolate(p, [0, 1], [0.35, 1]);
  const rot = interpolate(p, [0, 1], [-14, 0]) + tilt;
  const lift = interpolate(p, [0, 1], [50, 0]);
  const float = Math.sin((frame + delay) / 26) * 7;
  // Ken Burns on the still: slow push-in for the whole scene
  const kb = interpolate(frame, [delay, duration], [1, 1.07], { easing: theme.ease.inOut, ...clampBoth });
  const ring = interpolate(frame, [delay + 2, delay + 28], [0, 1], { easing: theme.ease.out, ...clampBoth });
  const radius = size * theme.radius.tile;

  return (
    <div
      style={{
        width: size,
        height: size,
        position: "relative",
        opacity: Math.min(1, p * 1.6),
        transform: `translateY(${lift + float}px) scale(${scale}) rotate(${rot}deg)`,
      }}
    >
      {/* expanding ring as the logo lands */}
      <div
        style={{
          position: "absolute",
          inset: 0,
          borderRadius: radius,
          border: `3px solid ${ringColor}`,
          transform: `scale(${1 + ring * 0.6})`,
          opacity: (1 - ring) * 0.6,
        }}
      />
      <div style={{ position: "absolute", inset: 0, filter: theme.shadow.tile, transform: `scale(${kb})` }}>
        {logo === "youtube" ? (
          <div
            style={{
              width: size,
              height: size,
              borderRadius: radius,
              background: theme.colors.tile,
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            <Img
              src={staticFile("logos/youtube.png")}
              style={{ width: size * 0.66, height: (size * 0.66) / ASPECT.youtube, display: "block" }}
            />
          </div>
        ) : (
          <Img
            src={staticFile(`logos/${logo}.png`)}
            style={{ width: size, height: size / ASPECT[logo], display: "block" }}
          />
        )}
      </div>
    </div>
  );
};
