// Bundles Hind Siliguri locally (via @fontsource → woff2 files inside node_modules → webpack),
// so the video renders fully offline. Children mount only after the fonts are really loaded,
// which also lets text-fitting measure the final glyph widths.
import React, { useEffect, useState } from "react";
import { AbsoluteFill, continueRender, delayRender } from "remotion";
import "@fontsource/hind-siliguri/500.css";
import "@fontsource/hind-siliguri/600.css";
import "@fontsource/hind-siliguri/700.css";
import { theme } from "../theme";

const SAMPLE = "আ ক্ষ ন্ত্র র্ক শ্রী যুক্তাক্ষর ভিতরে কিভাবে Aa Bb music download";

export const FontGate: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [ready, setReady] = useState(false);
  const [handle] = useState(() => delayRender("Loading Hind Siliguri"));

  useEffect(() => {
    let alive = true;
    Promise.all(
      [500, 600, 700].map((w) => document.fonts.load(`${w} 64px "Hind Siliguri"`, SAMPLE)),
    )
      .catch(() => undefined)
      .then(() => alive && setReady(true));
    return () => {
      alive = false;
    };
  }, []);

  useEffect(() => {
    if (ready) continueRender(handle);
  }, [ready, handle]);

  if (!ready) return <AbsoluteFill style={{ background: theme.colors.bg }} />;
  return <>{children}</>;
};
