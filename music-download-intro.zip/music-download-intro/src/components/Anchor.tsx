import React from "react";

/** Places children so their CENTER sits at (x, y) on the 1920×1080 canvas. */
export const Anchor: React.FC<{ x: number; y: number; style?: React.CSSProperties; children: React.ReactNode }> = ({
  x,
  y,
  style,
  children,
}) => (
  <div style={{ position: "absolute", left: x, top: y, transform: "translate(-50%, -50%)", ...style }}>
    {children}
  </div>
);
