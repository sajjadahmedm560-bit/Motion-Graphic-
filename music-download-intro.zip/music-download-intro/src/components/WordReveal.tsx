// Word-by-word staggered reveal (3–6 frame spacing).
// Bengali rule: NEVER split inside a word (conjuncts, kar-signs and ref would break) —
// words are split on spaces only, letterSpacing is always 0.
import React, { useLayoutEffect, useRef, useState } from "react";
import { interpolate, useCurrentFrame } from "remotion";
import { theme } from "../theme";
import { useSpringAt } from "./motion";

export type Word = {
  text: string;
  /** extra style for this word (e.g. gradient keyword) */
  style?: React.CSSProperties;
  /** soft hero highlight sweep behind the word */
  sweep?: boolean;
  /** small bounce-pop emphasis instead of the default rise */
  pop?: boolean;
};

export const keywordStyle: React.CSSProperties = {
  backgroundImage: theme.gradients.keyword,
  WebkitBackgroundClip: "text",
  backgroundClip: "text",
  color: "transparent",
  WebkitTextFillColor: "transparent",
  paddingBottom: "0.06em",
};

const WordItem: React.FC<{ word: Word; delay: number; fontSize: number }> = ({ word, delay, fontSize }) => {
  const frame = useCurrentFrame();
  const p = useSpringAt(delay, word.pop ? theme.spring.bouncy : theme.spring.snappy);
  const sw = interpolate(frame, [delay + 6, delay + 20], [0, 1], { easing: theme.ease.out, extrapolateLeft: "clamp", extrapolateRight: "clamp" });
  return (
    <span
      style={{
        position: "relative",
        display: "inline-block",
        whiteSpace: "nowrap",
        opacity: Math.min(1, p * 1.6),
        transform: word.pop
          ? `scale(${interpolate(p, [0, 1], [0.5, 1])})`
          : `translateY(${interpolate(p, [0, 1], [fontSize * 0.28, 0])}px) scale(${interpolate(p, [0, 1], [0.96, 1])})`,
      }}
    >
      {word.sweep ? (
        <span
          style={{
            position: "absolute",
            left: -fontSize * 0.12,
            right: -fontSize * 0.12,
            top: fontSize * 0.2,
            bottom: fontSize * 0.1,
            borderRadius: fontSize * 0.2,
            background: theme.colors.heroSoft,
            transformOrigin: "left center",
            transform: `scaleX(${sw})`,
          }}
        />
      ) : null}
      <span style={{ position: "relative", ...word.style }}>{word.text}</span>
    </span>
  );
};

export const WordReveal: React.FC<{
  words: Word[];
  delay: number;
  per?: number;
  fontSize: number;
  weight?: number;
  color?: string;
  align?: "left" | "center";
  lineHeight?: number;
  /** shrink-to-fit safety net: if the single line is wider than this, it is scaled down */
  maxWidth?: number;
  style?: React.CSSProperties;
}> = ({
  words,
  delay,
  per = 4,
  fontSize,
  weight = theme.weights.hero,
  color = theme.colors.text,
  align = "left",
  lineHeight = 1.35,
  maxWidth,
  style,
}) => {
  const ref = useRef<HTMLDivElement>(null);
  const [fit, setFit] = useState(1);

  useLayoutEffect(() => {
    if (!maxWidth || !ref.current) return;
    const natural = ref.current.offsetWidth;
    const next = natural > maxWidth ? maxWidth / natural : 1;
    if (Math.abs(next - fit) > 0.002) setFit(next);
  });

  return (
    <div style={{ display: "flex", justifyContent: align === "center" ? "center" : "flex-start" }}>
      <div
        ref={ref}
        style={{
          display: "inline-flex",
          flexWrap: "nowrap",
          columnGap: Math.round(fontSize * 0.27),
          fontFamily: theme.fonts.display,
          fontSize,
          fontWeight: weight,
          lineHeight,
          letterSpacing: 0,
          color,
          transform: fit < 1 ? `scale(${fit})` : undefined,
          transformOrigin: align === "center" ? "center center" : "left center",
          ...style,
        }}
      >
        {words.map((w, i) => (
          <WordItem key={i} word={w} delay={delay + i * per} fontSize={fontSize} />
        ))}
      </div>
    </div>
  );
};
