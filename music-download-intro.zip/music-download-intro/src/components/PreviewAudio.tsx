// Plays public/voiceover.mp3 in Remotion Studio so you can check sync.
// - File missing  -> renders nothing (no error, no silence-padding).
// - Rendering     -> off unless FLAGS.voiceoverInRender is true (default false).
import React, { useEffect, useState } from "react";
import { Audio, continueRender, delayRender, getRemotionEnvironment, staticFile } from "remotion";
import { FLAGS, VOICEOVER_FILE } from "../config";

const isActive = (): boolean => {
  if (!FLAGS.previewVoiceover) return false;
  return getRemotionEnvironment().isRendering ? FLAGS.voiceoverInRender : true;
};

export const PreviewAudio: React.FC = () => {
  const active = isActive();
  const [exists, setExists] = useState(false);
  const [handle] = useState(() => (active ? delayRender("Checking voiceover.mp3") : null));

  useEffect(() => {
    if (!active) return;
    let alive = true;
    fetch(staticFile(VOICEOVER_FILE), { method: "HEAD" })
      .then((r) => {
        const type = r.headers.get("content-type") ?? "";
        if (alive) setExists(r.ok && !type.includes("text/html"));
      })
      .catch(() => alive && setExists(false))
      .finally(() => {
        if (handle !== null) continueRender(handle);
      });
    return () => {
      alive = false;
    };
  }, [active, handle]);

  if (!active || !exists) return null;
  return <Audio src={staticFile(VOICEOVER_FILE)} />;
};
