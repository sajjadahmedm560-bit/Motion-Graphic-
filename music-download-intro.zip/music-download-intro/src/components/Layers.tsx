// Persistent layers of the 5-layer stack: BgMesh (bottom) … Grade, Grain, Vignette (top).
import React from "react";
import { AbsoluteFill, useCurrentFrame } from "remotion";
import { alpha, theme } from "../theme";

export const BgMesh: React.FC = () => {
  const frame = useCurrentFrame();
  const d1 = Math.sin(frame / 55) * 60;
  const d2 = Math.cos(frame / 70) * 50;
  const drift = (frame * 0.35) % 48;
  return (
    <AbsoluteFill style={{ background: theme.colors.bg }}>
      <div
        style={{
          position: "absolute",
          width: 1300,
          height: 1300,
          borderRadius: "50%",
          top: -560,
          left: -380 + d1,
          filter: "blur(60px)",
          background: `radial-gradient(circle, ${alpha(theme.colors.hero, 0.26)}, transparent 62%)`,
        }}
      />
      <div
        style={{
          position: "absolute",
          width: 1000,
          height: 1000,
          borderRadius: "50%",
          bottom: -480,
          right: -300 - d2,
          filter: "blur(70px)",
          background: `radial-gradient(circle, ${alpha(theme.colors.accent, 0.16)}, transparent 65%)`,
        }}
      />
      {/* faint dot grid for tech texture, drifting slowly */}
      <div
        style={{
          position: "absolute",
          inset: -48,
          backgroundImage: `radial-gradient(${alpha("#FFFFFF", 0.08)} 1.6px, transparent 1.8px)`,
          backgroundSize: "48px 48px",
          transform: `translate(${drift}px, ${drift * 0.6}px)`,
          WebkitMaskImage: "radial-gradient(ellipse at center, black 30%, transparent 78%)",
          maskImage: "radial-gradient(ellipse at center, black 30%, transparent 78%)",
        }}
      />
    </AbsoluteFill>
  );
};

/** Unifies everything with a faint hero tint + gentle top/bottom darkening. */
export const Grade: React.FC = () => (
  <AbsoluteFill style={{ pointerEvents: "none" }}>
    <AbsoluteFill style={{ backgroundColor: theme.colors.hero, mixBlendMode: "soft-light", opacity: 0.16 }} />
    <AbsoluteFill
      style={{
        background:
          "linear-gradient(180deg, rgba(0,0,0,0.12), transparent 26%, transparent 74%, rgba(0,0,0,0.2))",
      }}
    />
  </AbsoluteFill>
);

/** Procedural film grain (no asset file). */
export const Grain: React.FC = () => {
  const frame = useCurrentFrame();
  const noise = `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='220' height='220'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='2'/%3E%3C/filter%3E%3Crect width='220' height='220' filter='url(%23n)' opacity='0.5'/%3E%3C/svg%3E")`;
  return (
    <AbsoluteFill
      style={{
        pointerEvents: "none",
        backgroundImage: noise,
        backgroundSize: "220px",
        backgroundPosition: `${(frame * 7) % 220}px ${(frame * 13) % 220}px`,
        opacity: 0.06,
        mixBlendMode: "overlay",
      }}
    />
  );
};

export const Vignette: React.FC = () => (
  <AbsoluteFill
    style={{
      pointerEvents: "none",
      background: "radial-gradient(ellipse at center, transparent 58%, rgba(0,0,0,0.3) 100%)",
    }}
  />
);
