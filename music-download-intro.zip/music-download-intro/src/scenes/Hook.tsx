// Scene 1 · HOOK (cues 1–5) — "YouTube / TikTok-এ গান দেখেন তখন"
// Style: Glossy logo tiles + Kinetic Typography. Layout: two tiles on top, centered headline below.
import React from "react";
import { AbsoluteFill } from "remotion";
import { Anchor } from "../components/Anchor";
import { Equalizer } from "../components/Equalizer";
import { LogoTile } from "../components/LogoTile";
import { Entrance, glass } from "../components/motion";
import { Sfx } from "../components/Sfx";
import { keywordStyle, WordReveal } from "../components/WordReveal";
import { useScene } from "../scene";
import { theme } from "../theme";

const label: React.CSSProperties = {
  fontFamily: theme.fonts.display,
  fontSize: 46,
  fontWeight: theme.weights.strong,
  color: theme.colors.textDim,
  letterSpacing: 0,
  lineHeight: 1.3,
};

export const Hook: React.FC = () => {
  const { at } = useScene();
  const tYT = at(1); //   "YouTube এর"
  const tOr = at(2); //   "ভিতরে গিয়ে বা"
  const tTT = at(3); //   "TikTok এর"
  const tHead = at(4); // "গিয়ে যখন গান দেখেন"

  return (
    <AbsoluteFill>
      <Sfx name="thud" at={0} />
      <Sfx name="chime" at={tYT + 1} />
      <Sfx name="chime" at={tTT + 1} rate={1.1} volume={0.9} />
      <Sfx name="swipe" at={tHead} />

      <Anchor x={620} y={360}>
        <LogoTile logo="youtube" size={300} delay={tYT} tilt={-3} />
      </Anchor>
      <Anchor x={620} y={568}>
        <Entrance delay={tYT + 8} y={22}>
          <div style={label}>YouTube</div>
        </Entrance>
      </Anchor>

      <Anchor x={960} y={360}>
        <Entrance delay={tOr} y={0} scaleFrom={0.4} cfg={theme.spring.bouncy}>
          <div
            style={{
              ...glass(theme.radius.pill),
              width: 108,
              height: 108,
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              fontFamily: theme.fonts.display,
              fontSize: 48,
              fontWeight: theme.weights.strong,
              color: theme.colors.text,
              lineHeight: 1,
            }}
          >
            বা
          </div>
        </Entrance>
      </Anchor>

      <Anchor x={1300} y={360}>
        <LogoTile logo="tiktok" size={300} delay={tTT} tilt={3} />
      </Anchor>
      <Anchor x={1300} y={568}>
        <Entrance delay={tTT + 8} y={22}>
          <div style={label}>TikTok</div>
        </Entrance>
      </Anchor>

      <Anchor x={960} y={778} style={{ width: 1600 }}>
        <WordReveal
          words={[{ text: "যখন" }, { text: "গান", style: keywordStyle }, { text: "দেখেন" }]}
          delay={tHead}
          per={4}
          fontSize={150}
          align="center"
          maxWidth={1500}
        />
      </Anchor>

      <Anchor x={960} y={955}>
        <Equalizer count={34} barWidth={12} gap={12} maxHeight={84} delay={tHead + 8} />
      </Anchor>
    </AbsoluteFill>
  );
};
