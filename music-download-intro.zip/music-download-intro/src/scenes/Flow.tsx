// Scene 3 · FLOW (cues 14–17) — "download করে background এ রেখে নিজের মতো গান গাইতে"
// Style: Timeline / Process Flow with glass cards. Layout: three cards in a row + drawn connectors.
// Cue 14 names two items (download, background) → shown at equal spacing across that cue's time.
import React from "react";
import { AbsoluteFill, interpolate, useCurrentFrame } from "remotion";
import { Anchor } from "../components/Anchor";
import { DownloadIcon, LayersIcon, MicIcon } from "../components/Icons";
import { Entrance, Float, glass, useSpringAt } from "../components/motion";
import { Sfx } from "../components/Sfx";
import { useScene } from "../scene";
import { alpha, clampBoth, theme } from "../theme";

const CARD_W = 440;
const CARD_H = 520;
const CARD_TOP = 280;
const XS = [380, 960, 1540];

const Connector: React.FC<{ x1: number; x2: number; delay: number }> = ({ x1, x2, delay }) => {
  const frame = useCurrentFrame();
  const draw = interpolate(frame, [delay, delay + 14], [0, 1], { easing: theme.ease.out, ...clampBoth });
  const w = x2 - x1;
  const dot = ((frame - delay - 14) / 26) % 1;
  return (
    <div style={{ position: "absolute", left: x1, top: CARD_TOP + CARD_H / 2 - 20, width: w, height: 40 }}>
      <svg width={w} height={40} viewBox={`0 0 ${w} 40`} style={{ overflow: "visible" }}>
        <line
          x1={0}
          y1={20}
          x2={w - 16}
          y2={20}
          stroke={theme.colors.accent}
          strokeWidth={5}
          strokeLinecap="round"
          strokeDasharray="1"
          pathLength={1}
          strokeDashoffset={1 - draw}
        />
        <path
          d={`M${w - 30} 6 L${w - 6} 20 L${w - 30} 34`}
          fill="none"
          stroke={theme.colors.accent}
          strokeWidth={5}
          strokeLinecap="round"
          strokeLinejoin="round"
          opacity={draw > 0.85 ? 1 : 0}
        />
        {frame > delay + 14 ? <circle cx={dot * (w - 24)} cy={20} r={7} fill={theme.colors.text} opacity={1 - Math.abs(dot - 0.5) * 1.2} /> : null}
      </svg>
    </div>
  );
};

const Node: React.FC<{
  x: number;
  index: string;
  label: string;
  delay: number;
  hero?: boolean;
  children: React.ReactNode;
}> = ({ x, index, label, delay, hero, children }) => (
  <div style={{ position: "absolute", left: x - CARD_W / 2, top: CARD_TOP }}>
    <Entrance delay={delay} y={70} scaleFrom={0.86} cfg={theme.spring.bouncy}>
      <Float amp={7} period={100} phase={delay * 3} breathe={0.008}>
        <div
          style={{
            ...glass(theme.radius.card),
            width: CARD_W,
            height: CARD_H,
            boxSizing: "border-box",
            padding: "34px 36px 40px",
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            justifyContent: "space-between",
            border: hero ? `2px solid ${theme.colors.hero}` : `1px solid ${theme.colors.border}`,
            boxShadow: hero
              ? `0 0 80px ${theme.colors.heroGlow}, ${theme.shadow.card}`
              : theme.shadow.card,
          }}
        >
          <div
            style={{
              alignSelf: "flex-start",
              fontFamily: theme.fonts.display,
              fontSize: 40,
              fontWeight: theme.weights.strong,
              color: theme.colors.textFaint,
              letterSpacing: 0,
              lineHeight: 1.2,
            }}
          >
            {index}
          </div>
          <div
            style={{
              width: 220,
              height: 220,
              borderRadius: 56,
              background: theme.colors.surface,
              border: `1px solid ${theme.colors.border}`,
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              position: "relative",
            }}
          >
            {children}
          </div>
          <div
            style={{
              fontFamily: theme.fonts.display,
              fontSize: 58,
              fontWeight: theme.weights.hero,
              color: theme.colors.text,
              letterSpacing: 0,
              lineHeight: 1.3,
            }}
          >
            {label}
          </div>
        </div>
      </Float>
    </Entrance>
  </div>
);

export const Flow: React.FC = () => {
  const frame = useCurrentFrame();
  const { at, atItem } = useScene();
  const t1 = atItem(14, 0, 2); // download
  const t2 = atItem(14, 1, 2); // background
  const tReach = at(15); //      "এ রেখে আপনি" → arrow reaches toward the next step
  const t3 = at(16); //          "নিজের মতো করে" → mic card
  const tSing = at(17); //       "গান গাইতে" → sound rings

  const bob = (Math.sin(frame / 8) + 1) / 2;
  const ghost = interpolate(frame, [tReach + 6, tReach + 16, t3 + 4, t3 + 12], [0, 1, 1, 0], clampBoth);
  const micOn = useSpringAt(tSing, theme.spring.smooth);

  return (
    <AbsoluteFill>
      <Sfx name="whoosh" at={0} />
      <Sfx name="pop" at={t1 + 1} />
      <Sfx name="pop" at={t2 + 1} rate={1.07} volume={0.95} />
      <Sfx name="pop" at={t3 + 1} rate={0.94} />

      <Connector x1={XS[0] + CARD_W / 2 + 22} x2={XS[1] - CARD_W / 2 - 22} delay={t2 + 6} />
      <Connector x1={XS[1] + CARD_W / 2 + 22} x2={XS[2] - CARD_W / 2 - 22} delay={tReach + 4} />

      {/* placeholder for step 3 while the arrow "reaches" for it */}
      <div
        style={{
          position: "absolute",
          left: XS[2] - CARD_W / 2,
          top: CARD_TOP,
          width: CARD_W,
          height: CARD_H,
          borderRadius: theme.radius.card,
          border: `3px dashed ${theme.colors.textFaint}`,
          opacity: ghost * 0.9,
          transform: `scale(${0.96 + 0.04 * ghost})`,
        }}
      />

      <Node x={XS[0]} index="01" label="download" delay={t1}>
        <DownloadIcon size={124} color={theme.colors.accent} strokeWidth={4.5} t={bob} />
      </Node>

      <Node x={XS[1]} index="02" label="background" delay={t2}>
        <LayersIcon size={124} color={theme.colors.text} strokeWidth={4.5} />
      </Node>

      <Node x={XS[2]} index="03" label="গান গাওয়া" delay={t3} hero>
        {[0, 1, 2].map((k) => {
          const pr = ((frame - tSing + k * 10) % 30) / 30;
          const on = frame >= tSing;
          return (
            <div
              key={k}
              style={{
                position: "absolute",
                width: 130,
                height: 130,
                borderRadius: "50%",
                border: `3px solid ${theme.colors.accent}`,
                opacity: on ? (1 - pr) * 0.75 * micOn : 0,
                transform: `scale(${1 + pr * 0.95})`,
              }}
            />
          );
        })}
        <div style={{ transform: `scale(${1 + 0.08 * micOn})` }}>
          <MicIcon size={124} color={theme.colors.text} strokeWidth={4.5} />
        </div>
      </Node>

      {/* soft accent glow under the row for depth */}
      <Anchor x={960} y={880}>
        <div
          style={{
            width: 1200,
            height: 60,
            borderRadius: "50%",
            background: `radial-gradient(ellipse, ${alpha(theme.colors.accent, 0.16)}, transparent 70%)`,
            filter: "blur(20px)",
          }}
        />
      </Anchor>
    </AbsoluteFill>
  );
};
