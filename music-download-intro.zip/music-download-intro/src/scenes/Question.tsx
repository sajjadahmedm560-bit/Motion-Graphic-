// Scene 4 · QUESTION (cues 18–20) — "এখন কথা হচ্ছে, এই গানটি কিভাবে download দিবেন?"
// Style: Statement card / kinetic typography with one giant glyph. Layout: text left, huge "?" right.
import React from "react";
import { AbsoluteFill, interpolate, useCurrentFrame } from "remotion";
import { Anchor } from "../components/Anchor";
import { ArrowDown, MusicNote } from "../components/Icons";
import { Entrance, Float, glass, useSpringAt } from "../components/motion";
import { Sfx } from "../components/Sfx";
import { WordReveal } from "../components/WordReveal";
import { useScene } from "../scene";
import { theme } from "../theme";

export const Question: React.FC = () => {
  const frame = useCurrentFrame();
  const { at } = useScene();
  const tQ = at(18); //    "এখন কথা হচ্ছে"
  const tChip = at(19); // "এই গানটি আপনি"
  const tHead = at(20); // "কিভাবে download দিবেন?"

  const q = useSpringAt(tQ, theme.spring.bouncy);
  const bob = (Math.sin(frame / 9) + 1) / 2;

  return (
    <AbsoluteFill>
      <Sfx name="whoosh" at={0} />
      <Sfx name="pop" at={tQ + 2} rate={0.9} />
      <Sfx name="pop" at={tChip + 1} volume={0.9} />
      <Sfx name="swipe" at={tHead} />

      {/* giant question mark — the one hero element of this scene */}
      <Anchor x={1490} y={540}>
        <Float amp={12} period={110} breathe={0.015}>
          <div
            style={{
              fontFamily: theme.fonts.display,
              fontWeight: theme.weights.hero,
              fontSize: 840,
              lineHeight: 1,
              letterSpacing: 0,
              backgroundImage: theme.gradients.keyword,
              WebkitBackgroundClip: "text",
              backgroundClip: "text",
              color: "transparent",
              WebkitTextFillColor: "transparent",
              filter: `drop-shadow(0 0 70px ${theme.colors.heroGlow})`,
              opacity: Math.min(1, q * 1.6),
              transform: `scale(${interpolate(q, [0, 1], [0.35, 1])}) rotate(${interpolate(q, [0, 1], [-16, 5])}deg)`,
            }}
          >
            ?
          </div>
        </Float>
      </Anchor>

      {/* "this song" chip + arrow */}
      <div style={{ position: "absolute", left: 140, top: 236 }}>
        <Entrance delay={tChip} x={-50} y={0} scaleFrom={0.9}>
          <div
            style={{
              ...glass(theme.radius.pill),
              display: "inline-flex",
              alignItems: "center",
              gap: 20,
              padding: "12px 42px 12px 30px",
              fontFamily: theme.fonts.display,
              fontSize: 58,
              fontWeight: theme.weights.strong,
              color: theme.colors.text,
              letterSpacing: 0,
              lineHeight: 1.35,
            }}
          >
            <MusicNote size={52} color={theme.colors.accent} />
            এই গানটি
          </div>
        </Entrance>
      </div>
      <div style={{ position: "absolute", left: 178, top: 352, opacity: Math.min(1, useSpringAt(tChip + 6) * 1.6) }}>
        <div style={{ transform: `translateY(${bob * 10}px)` }}>
          <ArrowDown size={56} color={theme.colors.accent} strokeWidth={5} />
        </div>
      </div>

      {/* headline */}
      <div style={{ position: "absolute", left: 140, top: 440 }}>
        <WordReveal
          words={[{ text: "কিভাবে" }, { text: "download", style: { color: theme.colors.accent } }]}
          delay={tHead}
          per={5}
          fontSize={124}
          maxWidth={1060}
        />
        <WordReveal words={[{ text: "দিবেন?" }]} delay={tHead + 10} fontSize={124} maxWidth={1060} />
      </div>
    </AbsoluteFill>
  );
};
