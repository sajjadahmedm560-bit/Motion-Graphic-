// Scene 5 · CAPCUT (cues 21–23) — "এই বিষয়টা দেখানোর জন্য অবশ্যই CapCut টি open করবেন।"
// Style: Glossy UI mockup (editor window) → logo reveal → Open button with cursor tap. Clean ending.
import React from "react";
import { AbsoluteFill, interpolate, useCurrentFrame } from "remotion";
import { Anchor } from "../components/Anchor";
import { Cursor, PlayIcon } from "../components/Icons";
import { LogoTile } from "../components/LogoTile";
import { Entrance, Float, glass } from "../components/motion";
import { Sfx } from "../components/Sfx";
import { WordReveal } from "../components/WordReveal";
import { useScene } from "../scene";
import { alpha, clampBoth, theme } from "../theme";

const CLIPS: { row: number; x: number; w: number; strong?: boolean }[] = [
  { row: 0, x: 0, w: 210, strong: true },
  { row: 0, x: 226, w: 150 },
  { row: 0, x: 392, w: 250, strong: true },
  { row: 1, x: 60, w: 180 },
  { row: 1, x: 256, w: 290 },
  { row: 2, x: 0, w: 330, strong: true },
  { row: 2, x: 346, w: 170 },
];

const EditorWindow: React.FC = () => {
  const frame = useCurrentFrame();
  const playhead = 150 + frame * 3.2;
  return (
    <div
      style={{
        ...glass(40),
        width: 1320,
        height: 760,
        overflow: "hidden",
        display: "flex",
        flexDirection: "column",
        boxSizing: "border-box",
      }}
    >
      <div style={{ height: 64, display: "flex", alignItems: "center", gap: 12, padding: "0 28px", borderBottom: `1px solid ${theme.colors.border}` }}>
        {[0, 1, 2].map((i) => (
          <div key={i} style={{ width: 16, height: 16, borderRadius: 8, background: theme.colors.surfaceStrong }} />
        ))}
        <div style={{ flex: 1 }} />
        <div style={{ width: 220, height: 16, borderRadius: 8, background: theme.colors.surface }} />
        <div style={{ flex: 1 }} />
      </div>
      <div style={{ flex: 1, display: "flex", gap: 24, padding: 24 }}>
        <div style={{ width: 300, display: "grid", gridTemplateColumns: "1fr 1fr", gridAutoRows: 118, gap: 16, alignContent: "start" }}>
          {Array.from({ length: 6 }).map((_, i) => (
            <div key={i} style={{ borderRadius: 18, background: i % 3 === 0 ? theme.colors.accentSoft : theme.colors.surface, border: `1px solid ${theme.colors.border}` }} />
          ))}
        </div>
        <div
          style={{
            flex: 1,
            borderRadius: 26,
            background: theme.colors.bgAlt,
            border: `1px solid ${theme.colors.border}`,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
          }}
        >
          <PlayIcon size={72} color={theme.colors.textFaint} />
        </div>
      </div>
      <div style={{ position: "relative", height: 210, margin: "0 24px 24px", borderRadius: 22, background: theme.colors.surface, border: `1px solid ${theme.colors.border}`, overflow: "hidden" }}>
        {CLIPS.map((c, i) => (
          <div
            key={i}
            style={{
              position: "absolute",
              left: 24 + c.x,
              top: 22 + c.row * 56,
              width: c.w,
              height: 40,
              borderRadius: 12,
              background: c.strong ? theme.colors.accentSoft : theme.colors.surfaceStrong,
              border: `1px solid ${theme.colors.border}`,
            }}
          />
        ))}
        <div style={{ position: "absolute", left: playhead, top: 0, bottom: 0, width: 4, background: theme.colors.accent, opacity: 0.9 }} />
      </div>
    </div>
  );
};

export const CapCut: React.FC = () => {
  const frame = useCurrentFrame();
  const { at } = useScene();
  const tWin = at(21); //  "এই বিষয়টা দেখানোর"
  const tLogo = at(22); // "জন্য অবশ্যই CapCut"
  const tOpen = at(23); // "টি open করবেন"

  const dim = interpolate(frame, [tLogo, tLogo + 14], [0, 1], { easing: theme.ease.out, ...clampBoth });
  const glow = interpolate(frame, [tLogo, tLogo + 18], [0, 1], { easing: theme.ease.out, ...clampBoth });

  // cursor glides to the button, then taps
  const curT = interpolate(frame, [tOpen, tOpen + 14], [0, 1], { easing: theme.ease.inOut, ...clampBoth });
  const tap = tOpen + 16;
  const cx = interpolate(curT, [0, 1], [1560, 1000]);
  const cy = interpolate(curT, [0, 1], [985, 818]);
  const press = interpolate(frame, [tap, tap + 3, tap + 9], [1, 0.93, 1], { easing: theme.ease.out, ...clampBoth });
  const ripple = interpolate(frame, [tap, tap + 18], [0, 1], { easing: theme.ease.out, ...clampBoth });
  const curOn = interpolate(frame, [tOpen - 2, tOpen + 4], [0, 1], clampBoth);

  return (
    <AbsoluteFill>
      <Sfx name="whoosh" at={0} />
      <Sfx name="chime" at={tLogo + 1} />
      <Sfx name="click" at={tap} />

      {/* editor window (the tool), dims once the logo takes focus */}
      <Anchor x={960} y={540} style={{ opacity: 1 - 0.62 * dim, transform: `translate(-50%, -50%) scale(${1 - 0.04 * dim})` }}>
        <Entrance delay={tWin} y={70} scaleFrom={0.92}>
          <EditorWindow />
        </Entrance>
      </Anchor>

      {/* glow + CapCut logo */}
      <Anchor x={960} y={372}>
        <div
          style={{
            width: 620,
            height: 620,
            borderRadius: "50%",
            background: `radial-gradient(circle, ${alpha(theme.colors.accent, 0.3)}, transparent 66%)`,
            opacity: glow,
            transform: `scale(${0.7 + 0.3 * glow})`,
          }}
        />
      </Anchor>
      <Anchor x={960} y={372}>
        <LogoTile logo="capcut" size={270} delay={tLogo} ringColor={theme.colors.accent} />
      </Anchor>
      <Anchor x={960} y={598} style={{ width: 900 }}>
        <WordReveal words={[{ text: "CapCut" }]} delay={tLogo + 8} fontSize={104} align="center" />
      </Anchor>

      {/* Open button — the single hero-colored element */}
      <Anchor x={960} y={800}>
        <Entrance delay={tOpen} y={40} scaleFrom={0.8} cfg={theme.spring.bouncy}>
          <Float amp={4} period={90} breathe={0.01}>
            <div style={{ position: "relative", transform: `scale(${press})` }}>
              <div
                style={{
                  position: "absolute",
                  inset: 0,
                  borderRadius: theme.radius.pill,
                  border: `3px solid ${theme.colors.text}`,
                  opacity: (1 - ripple) * 0.7,
                  transform: `scale(${1 + ripple * 0.55}, ${1 + ripple * 0.8})`,
                }}
              />
              <div
                style={{
                  width: 380,
                  height: 124,
                  borderRadius: theme.radius.pill,
                  background: theme.colors.hero,
                  boxShadow: `0 0 70px ${theme.colors.heroGlow}, 0 24px 50px -16px ${theme.colors.shadow}, inset 0 1px 0 rgba(255,255,255,0.35)`,
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  fontFamily: theme.fonts.display,
                  fontSize: 62,
                  fontWeight: theme.weights.hero,
                  color: theme.colors.text,
                  letterSpacing: 0,
                  lineHeight: 1.3,
                }}
              >
                Open
              </div>
            </div>
          </Float>
        </Entrance>
      </Anchor>

      <div style={{ position: "absolute", left: cx - 7, top: cy - 5, opacity: curOn, transform: `scale(${press})`, transformOrigin: "7px 5px" }}>
        <Cursor size={70} />
      </div>
    </AbsoluteFill>
  );
};
