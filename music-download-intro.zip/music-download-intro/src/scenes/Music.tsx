// Scene 2 · MUSIC (cues 6–13) — "একটা গান ভালো লেগে যায় … সেই গানের ভিতরের music"
// Style: Glossy UI mockup (player card) + Kinetic typography.
// Layout: text on the left, player card on the right.
import React from "react";
import { AbsoluteFill, interpolate, useCurrentFrame, useVideoConfig } from "remotion";
import { Equalizer } from "../components/Equalizer";
import { Heart, MusicNote, ArrowRight, PlayIcon, SkipIcon } from "../components/Icons";
import { Entrance, glass, useExit, useSpringAt } from "../components/motion";
import { Sfx } from "../components/Sfx";
import { keywordStyle, WordReveal } from "../components/WordReveal";
import { useScene } from "../scene";
import { alpha, clampBoth, theme } from "../theme";

const BARS = 36;

const Waveform: React.FC<{ focusAt: number }> = ({ focusAt }) => {
  const frame = useCurrentFrame();
  const { duration } = useScene();
  const focus = interpolate(frame, [focusAt, focusAt + 14], [0, 1], { easing: theme.ease.out, ...clampBoth });
  const progress = interpolate(frame, [0, duration], [0.12, 0.5], { easing: theme.ease.inOut, ...clampBoth });
  return (
    <div style={{ position: "relative", height: 84 }}>
      {/* bracket that "selects" the music inside the song */}
      <div
        style={{
          position: "absolute",
          inset: -12,
          borderRadius: 22,
          border: `2px solid ${theme.colors.accent}`,
          boxShadow: `0 0 36px ${theme.colors.accentGlow}, inset 0 0 24px ${theme.colors.accentSoft}`,
          opacity: focus,
          transform: `scale(${1.06 - 0.06 * focus})`,
        }}
      />
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", height: 84 }}>
        {Array.from({ length: BARS }).map((_, i) => {
          const base = 0.25 + 0.75 * Math.abs(Math.sin(i * 0.9 + 1.3) * Math.cos(i * 0.37));
          const wob = 0.8 + 0.2 * Math.sin(frame / 6 + i * 0.7);
          const h = 84 * Math.min(1, base * wob * (1 + 0.45 * focus));
          const played = i / BARS < progress || focus > 0.5;
          return (
            <div
              key={i}
              style={{
                width: 7,
                height: Math.max(8, h),
                borderRadius: 7,
                background: played ? theme.colors.accent : theme.colors.textFaint,
              }}
            />
          );
        })}
      </div>
    </div>
  );
};

const PlayerCard: React.FC<{ likeAt: number; focusAt: number }> = ({ likeAt, focusAt }) => {
  const frame = useCurrentFrame();
  const like = useSpringAt(likeAt, theme.spring.bouncy);
  return (
    <div
      style={{
        ...glass(theme.radius.card),
        width: 560,
        height: 760,
        padding: 40,
        boxSizing: "border-box",
        display: "flex",
        flexDirection: "column",
        gap: 26,
      }}
    >
      {/* cover art */}
      <div
        style={{
          position: "relative",
          height: 372,
          borderRadius: theme.radius.inner,
          overflow: "hidden",
          background: `radial-gradient(circle at 28% 22%, ${alpha(theme.colors.hero, 0.5)}, transparent 58%), radial-gradient(circle at 78% 84%, ${alpha(theme.colors.accent, 0.32)}, transparent 55%), ${theme.colors.bgAlt}`,
          border: `1px solid ${theme.colors.border}`,
        }}
      >
        {[330, 232].map((s, k) => (
          <div
            key={s}
            style={{
              position: "absolute",
              left: "50%",
              top: "50%",
              width: s,
              height: s,
              marginLeft: -s / 2,
              marginTop: -s / 2,
              borderRadius: "50%",
              border: `2px ${k ? "dashed" : "solid"} ${theme.colors.border}`,
              transform: `rotate(${frame * (k ? -0.6 : 0.4)}deg)`,
            }}
          />
        ))}
        <div style={{ position: "absolute", left: "50%", top: "50%", transform: "translate(-50%, -50%)" }}>
          <MusicNote size={132} color={theme.colors.text} />
        </div>
      </div>

      {/* title skeleton + heart */}
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", height: 56 }}>
        <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
          <div style={{ width: 280, height: 20, borderRadius: 10, background: theme.colors.surfaceStrong }} />
          <div style={{ width: 176, height: 14, borderRadius: 7, background: theme.colors.surface }} />
        </div>
        <div style={{ position: "relative", width: 56, height: 52 }}>
          <Heart size={56} color={theme.colors.textDim} />
          <div
            style={{
              position: "absolute",
              inset: 0,
              opacity: Math.min(1, like * 1.6),
              transform: `scale(${interpolate(like, [0, 1], [0.4, 1])})`,
              filter: `drop-shadow(0 0 16px ${theme.colors.heroGlow})`,
            }}
          >
            <Heart size={56} color={theme.colors.hero} fill={theme.colors.hero} />
          </div>
          {/* tiny hearts floating up when liked */}
          {[0, 1, 2, 3, 4].map((i) => {
            const t = interpolate(frame, [likeAt + 2 + i * 3, likeAt + 34 + i * 3], [0, 1], {
              easing: theme.ease.out,
              ...clampBoth,
            });
            const dx = [-34, 26, -10, 40, -48][i];
            return (
              <div
                key={i}
                style={{
                  position: "absolute",
                  left: 18,
                  top: 10,
                  opacity: t === 0 ? 0 : (1 - t) * 0.9,
                  transform: `translate(${dx * t}px, ${-110 * t - i * 6}px) scale(${0.45 + i * 0.06})`,
                }}
              >
                <Heart size={30} color={theme.colors.accent} fill={theme.colors.accent} strokeWidth={0} />
              </div>
            );
          })}
        </div>
      </div>

      <Waveform focusAt={focusAt} />

      {/* transport controls */}
      <div style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: 46, marginTop: 4 }}>
        <SkipIcon size={44} dir="prev" color={theme.colors.textDim} />
        <div
          style={{
            width: 88,
            height: 88,
            borderRadius: "50%",
            background: theme.colors.text,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
          }}
        >
          <PlayIcon size={42} color={theme.colors.ink} style={{ marginLeft: 5 }} />
        </div>
        <SkipIcon size={44} dir="next" color={theme.colors.textDim} />
      </div>
    </div>
  );
};

export const Music: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  void fps;
  const { at } = useScene();
  const tCard = at(6); //     "কিন্তু একটা না…"
  const tH1a = at(7); //      "একটা গান ভালো"
  const tH1b = at(8); //      "লেগে যায়"
  const tH2 = at(9); //       "সবচেয়ে বেশি ভালো"
  const tChip = at(10); //    "লাগে সেই গানের"
  const tH3 = at(11); //      "ভিতরে যে music"
  const tPulse = at(13); //   "music টি"

  const exit1 = useExit(tH2 - 2);
  const exit2 = useExit(tH3 - 2);

  // card: slides in from the right in 3D, then sways; pushes in slightly on the "music" beat
  const p = useSpringAt(tCard, theme.spring.smooth);
  const push = interpolate(frame, [tH3, tH3 + 16], [0, 1], { easing: theme.ease.out, ...clampBoth });
  const sway = Math.sin(frame / 55) * 2.5;
  const bob = Math.sin(frame / 38) * 7;
  const pulse = interpolate(frame, [tPulse, tPulse + 6, tPulse + 18], [0, 1, 0], { easing: theme.ease.out, ...clampBoth });

  return (
    <AbsoluteFill>
      <Sfx name="whoosh" at={0} />
      <Sfx name="pop" at={tCard + 4} />
      <Sfx name="click" at={tH2 + 8} />
      <Sfx name="swipe" at={tH3} />
      <Sfx name="pop" at={tPulse} rate={1.08} volume={0.85} />

      {/* LEFT: text beats */}
      <div style={{ position: "absolute", left: 130, top: 332, ...exit1 }}>
        <WordReveal
          words={[{ text: "একটা" }, { text: "গান" }, { text: "ভালো" }]}
          delay={tH1a}
          fontSize={124}
          maxWidth={900}
        />
        <WordReveal words={[{ text: "লেগে" }, { text: "যায়" }]} delay={tH1b} fontSize={124} maxWidth={900} />
      </div>

      <div style={{ position: "absolute", left: 130, top: 332, ...exit2 }}>
        <WordReveal
          words={[{ text: "সবচেয়ে বেশি", sweep: true }]}
          delay={tH2}
          fontSize={124}
          maxWidth={900}
        />
        <WordReveal words={[{ text: "ভালো" }, { text: "লাগে" }]} delay={tH2 + 8} fontSize={124} maxWidth={900} />
        <div style={{ marginTop: 22 }}>
          <Entrance delay={tChip} x={-30} y={0} scaleFrom={0.9}>
            <div
              style={{
                ...glass(theme.radius.pill),
                display: "inline-flex",
                alignItems: "center",
                gap: 22,
                padding: "10px 38px 10px 34px",
                fontFamily: theme.fonts.display,
                fontSize: 60,
                fontWeight: theme.weights.strong,
                lineHeight: 1.35,
                letterSpacing: 0,
                color: theme.colors.textDim,
              }}
            >
              সেই গানের
              <ArrowRight size={44} color={theme.colors.accent} />
            </div>
          </Entrance>
        </div>
      </div>

      <div style={{ position: "absolute", left: 130, top: 292 }}>
        <WordReveal
          words={[{ text: "গানের" }, { text: "ভিতরের" }]}
          delay={tH3}
          fontSize={76}
          weight={theme.weights.strong}
          color={theme.colors.textDim}
          maxWidth={900}
        />
        <div style={{ transform: `scale(${1 + 0.07 * pulse})`, transformOrigin: "left center" }}>
          <WordReveal
            words={[{ text: "music", style: { ...keywordStyle, filter: `drop-shadow(0 0 40px ${theme.colors.heroGlow})` }, pop: true }]}
            delay={tH3 + 8}
            fontSize={250}
            lineHeight={1.12}
            maxWidth={900}
          />
        </div>
        <div style={{ marginTop: 10, marginLeft: 6 }}>
          <Equalizer count={22} barWidth={10} gap={10} maxHeight={56} delay={tH3 + 14} energy={0.9} />
        </div>
      </div>

      {/* RIGHT: player card */}
      <div
        style={{
          position: "absolute",
          left: 1100,
          top: 160,
          opacity: Math.min(1, p * 1.5),
          transform: `perspective(1800px) translate(${(1 - p) * 260}px, ${bob}px) rotateY(${interpolate(p, [0, 1], [-30, -9]) + sway}deg) scale(${interpolate(p, [0, 1], [0.9, 1]) + 0.05 * push})`,
        }}
      >
        <PlayerCard likeAt={tH1b + 4} focusAt={tH3 + 2} />
      </div>
    </AbsoluteFill>
  );
};
