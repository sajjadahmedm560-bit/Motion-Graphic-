// Scene boundaries are cue boundaries. A scene may hold several cues.
// Scene i+1 starts `lead` frames before its first cue is spoken, and scene i stays `xfade`
// frames longer so the two overlap during the transition.
import { cueIn, TOTAL_FRAMES } from "./srt";
import { theme } from "./theme";

export type SceneId = "hook" | "music" | "flow" | "question" | "capcut";

// firstCue = first SRT cue number that belongs to the scene.
const DEFS: { id: SceneId; firstCue: number }[] = [
  { id: "hook", firstCue: 1 }, //     cues 1–5   YouTube / TikTok
  { id: "music", firstCue: 6 }, //    cues 6–13  a song you love → its music
  { id: "flow", firstCue: 14 }, //    cues 14–17 download → background → sing
  { id: "question", firstCue: 18 }, // cues 18–20 how to download?
  { id: "capcut", firstCue: 21 }, //  cues 21–23 open CapCut
];

export const SCENES = DEFS.map((d, i) => {
  const from = i === 0 ? 0 : cueIn(d.firstCue) - theme.motion.lead;
  const next = DEFS[i + 1];
  const end = next ? cueIn(next.firstCue) - theme.motion.lead + theme.motion.xfade : TOTAL_FRAMES;
  return { id: d.id, from, duration: end - from };
});
