// Deterministic SFX synthesizer -> public/sfx/*.wav (16-bit, 44.1kHz, mono)
// Run: node scripts/make-sfx.mjs
import { writeFileSync, mkdirSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

const SR = 44100;
const OUT = join(dirname(fileURLToPath(import.meta.url)), "..", "public", "sfx");
mkdirSync(OUT, { recursive: true });

// ---------- helpers ----------
function rng(seed) {
  let a = seed >>> 0;
  return () => {
    a |= 0; a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
const N = (sec) => Math.round(sec * SR);
const noise = (n, seed) => { const r = rng(seed); return Float32Array.from({ length: n }, () => r() * 2 - 1); };

// RBJ biquad (type: lp | hp | bp). f may be a number or a per-sample function.
function biquad(x, type, f, Q = 0.707) {
  const y = new Float32Array(x.length);
  let x1 = 0, x2 = 0, y1 = 0, y2 = 0;
  for (let i = 0; i < x.length; i++) {
    const fc = Math.min(typeof f === "function" ? f(i) : f, SR * 0.45);
    const w = (2 * Math.PI * fc) / SR, cw = Math.cos(w), sw = Math.sin(w), al = sw / (2 * Q);
    let b0, b1, b2;
    if (type === "lp") { b0 = (1 - cw) / 2; b1 = 1 - cw; b2 = (1 - cw) / 2; }
    else if (type === "hp") { b0 = (1 + cw) / 2; b1 = -(1 + cw); b2 = (1 + cw) / 2; }
    else { b0 = al; b1 = 0; b2 = -al; } // bp (constant 0 dB peak)
    const a0 = 1 + al, a1 = -2 * cw, a2 = 1 - al;
    const o = (b0 * x[i] + b1 * x1 + b2 * x2 - a1 * y1 - a2 * y2) / a0;
    x2 = x1; x1 = x[i]; y2 = y1; y1 = o; y[i] = o;
  }
  return y;
}
const mix = (...arrs) => {
  const n = Math.max(...arrs.map((a) => a.length));
  const o = new Float32Array(n);
  for (const a of arrs) for (let i = 0; i < a.length; i++) o[i] += a[i];
  return o;
};
const gain = (x, g) => x.map((v) => v * g);

// very small, short reverb: 3 feedback combs (20-41 ms), mixed in low
function tinyReverb(x, wet = 0.12, tail = 0.12) {
  const n = x.length + N(tail);
  const out = new Float32Array(n);
  for (let i = 0; i < x.length; i++) out[i] = x[i];
  const combs = [[N(0.0207), 0.38], [N(0.0293), 0.33], [N(0.0411), 0.28]];
  const wetBuf = new Float32Array(n);
  for (const [d, fb] of combs) {
    const buf = new Float32Array(n);
    for (let i = 0; i < n; i++) {
      const inp = i < x.length ? x[i] : 0;
      buf[i] = inp + (i >= d ? buf[i - d] * fb : 0);
    }
    for (let i = 0; i < n; i++) wetBuf[i] += buf[i] / combs.length;
  }
  const smooth = biquad(wetBuf, "lp", 2800);
  for (let i = 0; i < n; i++) out[i] += smooth[i] * wet;
  return out;
}

function finish(x, { peak, fadeIn = 0.002, fadeOut = 0.03 }) {
  const y = Float32Array.from(x);
  const fi = N(fadeIn), fo = N(fadeOut);
  for (let i = 0; i < fi && i < y.length; i++) y[i] *= i / fi;
  for (let i = 0; i < fo && i < y.length; i++) y[y.length - 1 - i] *= i / fo;
  let p = 0;
  for (const v of y) p = Math.max(p, Math.abs(v));
  const g = peak / (p || 1);
  return y.map((v) => v * g);
}

function writeWav(name, x) {
  const buf = Buffer.alloc(44 + x.length * 2);
  buf.write("RIFF", 0); buf.writeUInt32LE(36 + x.length * 2, 4); buf.write("WAVE", 8);
  buf.write("fmt ", 12); buf.writeUInt32LE(16, 16); buf.writeUInt16LE(1, 20); buf.writeUInt16LE(1, 22);
  buf.writeUInt32LE(SR, 24); buf.writeUInt32LE(SR * 2, 28); buf.writeUInt16LE(2, 32); buf.writeUInt16LE(16, 34);
  buf.write("data", 36); buf.writeUInt32LE(x.length * 2, 40);
  for (let i = 0; i < x.length; i++) buf.writeInt16LE(Math.max(-32767, Math.min(32767, Math.round(x[i] * 32767))), 44 + i * 2);
  writeFileSync(join(OUT, name), buf);
  console.log(name.padEnd(12), (x.length / SR).toFixed(3) + "s");
}

// ---------- sounds ----------
// 1) pop: sine with fast downward pitch drop + short envelope (cards, UI reveals, nodes)
{
  const n = N(0.2); const o = new Float32Array(n); let ph = 0;
  for (let i = 0; i < n; i++) {
    const t = i / SR;
    const f = 170 + 400 * Math.exp(-t / 0.028);
    ph += (2 * Math.PI * f) / SR;
    const env = Math.min(1, t / 0.004) * Math.exp(-t / 0.05);
    o[i] = (Math.sin(ph) + 0.18 * Math.sin(2 * ph)) * env;
  }
  writeWav("pop.wav", finish(tinyReverb(biquad(o, "lp", 3400), 0.08, 0.05), { peak: 0.3, fadeOut: 0.05 }));
}

// 2) click: tiny high-passed noise burst (buttons, highlights)
{
  const n = N(0.08); const nz = noise(n, 7); const o = new Float32Array(n);
  for (let i = 0; i < n; i++) {
    const t = i / SR;
    o[i] = nz[i] * Math.exp(-t / 0.007) * Math.min(1, t / 0.0008)
         + 0.35 * Math.sin(2 * Math.PI * 2300 * t) * Math.exp(-t / 0.011);
  }
  const f = biquad(biquad(o, "hp", 1700), "lp", 7000);
  writeWav("click.wav", finish(tinyReverb(f, 0.06, 0.04), { peak: 0.3, fadeOut: 0.03 }));
}

// 3) whoosh: band-pass noise sweep with fade in / out (scene transitions)
{
  const d = 0.6, n = N(d);
  const sweep = biquad(noise(n, 21), "bp", (i) => 420 * Math.pow(7.2, i / n), 1.1);
  const o = sweep.map((v, i) => { const p = i / n; return v * Math.pow(Math.sin(Math.PI * Math.pow(p, 0.75)), 2); });
  writeWav("whoosh.wav", finish(tinyReverb(biquad(o, "lp", 6000), 0.1, 0.12), { peak: 0.32, fadeOut: 0.08 }));
}

// 4) swipe: shorter, airier whoosh (headline entries)
{
  const d = 0.32, n = N(d);
  const sweep = biquad(noise(n, 33), "bp", (i) => 900 * Math.pow(4.2, i / n), 1.4);
  const o = sweep.map((v, i) => { const p = i / n; return v * Math.pow(Math.sin(Math.PI * Math.pow(p, 0.7)), 2); });
  writeWav("swipe.wav", finish(tinyReverb(biquad(o, "lp", 6500), 0.08, 0.06), { peak: 0.26, fadeOut: 0.06 }));
}

// 5) chime: soft pluck with gentle overtones (logo reveals)
{
  const n = N(0.36); const o = new Float32Array(n);
  const partials = [[880, 1, 0.14], [1320, 0.22, 0.09], [1760, 0.32, 0.07], [2640, 0.1, 0.045]];
  for (let i = 0; i < n; i++) {
    const t = i / SR; let s = 0;
    for (const [f, a, tau] of partials) s += a * Math.sin(2 * Math.PI * f * (1 + 0.0012 * Math.sin(t * 9)) * t) * Math.exp(-t / tau);
    o[i] = s * Math.min(1, t / 0.004);
  }
  const click = biquad(noise(N(0.02), 5), "lp", 4200).map((v, i) => v * Math.exp(-i / SR / 0.004) * 0.25);
  writeWav("chime.wav", finish(tinyReverb(biquad(mix(o, click), "lp", 5200), 0.14, 0.09), { peak: 0.28, fadeOut: 0.1 }));
}

// 6) thud: very soft low sine (hook)
{
  const n = N(0.32); const o = new Float32Array(n); let ph = 0;
  for (let i = 0; i < n; i++) {
    const t = i / SR;
    ph += (2 * Math.PI * (52 + 45 * Math.exp(-t / 0.05))) / SR;
    o[i] = Math.sin(ph) * Math.min(1, t / 0.007) * Math.exp(-t / 0.085);
  }
  writeWav("thud.wav", finish(biquad(o, "lp", 380), { peak: 0.3, fadeOut: 0.09 }));
}
